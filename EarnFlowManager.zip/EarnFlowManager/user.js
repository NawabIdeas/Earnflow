// User Authentication and Session Management
let adTimer = null;
let currentAd = null;
let adStartTime = null;
let lastAdTime = 0;

// Initialize user session
document.addEventListener('DOMContentLoaded', function() {
    checkUserSession();
});

function checkUserSession() {
    const savedUser = localStorage.getItem('earnflow_user');
    if (savedUser) {
        const userData = JSON.parse(savedUser);
        auth.signInWithEmailAndPassword(userData.email, userData.password)
            .then(() => {
                currentUser = auth.currentUser;
                loadUserProfile();
                showAppContainer();
            })
            .catch(() => {
                localStorage.removeItem('earnflow_user');
                showAuthContainer();
            });
    } else {
        showAuthContainer();
    }
}

function showAuthContainer() {
    document.getElementById('authContainer').classList.remove('hidden');
    document.getElementById('appContainer').classList.add('hidden');
}

function showAppContainer() {
    document.getElementById('authContainer').classList.add('hidden');
    document.getElementById('appContainer').classList.remove('hidden');
    showDashboard();
}

function showLoginForm() {
    document.getElementById('loginForm').classList.remove('hidden');
    document.getElementById('registerForm').classList.add('hidden');
}

function showRegisterForm() {
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('registerForm').classList.remove('hidden');
}

function userLogin() {
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    
    if (!email || !password) {
        showMessage('Please fill in all fields', 'error');
        return;
    }
    
    showLoader(true);
    
    auth.signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            currentUser = userCredential.user;
            localStorage.setItem('earnflow_user', JSON.stringify({email, password}));
            loadUserProfile();
            showAppContainer();
            showMessage('Login successful!', 'success');
        })
        .catch((error) => {
            showMessage('Login failed: ' + error.message, 'error');
        })
        .finally(() => {
            showLoader(false);
        });
}

function userRegister() {
    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value.trim();
    const confirmPassword = document.getElementById('confirmPassword').value.trim();
    const referralCode = document.getElementById('referralCode').value.trim();
    
    if (!name || !email || !password || !confirmPassword) {
        showMessage('Please fill in all required fields', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showMessage('Passwords do not match', 'error');
        return;
    }
    
    if (password.length < 6) {
        showMessage('Password must be at least 6 characters', 'error');
        return;
    }
    
    showLoader(true);
    
    auth.createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            currentUser = userCredential.user;
            
            // Create user profile in database
            const userData = {
                uid: currentUser.uid,
                name: name,
                email: email,
                balance: 0,
                totalEarned: 0,
                referralCode: generateReferralCode(),
                referredBy: referralCode || null,
                joinDate: Date.now(),
                lastActive: Date.now(),
                dailyCheckStatus: {},
                status: 'active'
            };
            
            return database.ref('users/' + currentUser.uid).set(userData);
        })
        .then(() => {
            // Handle referral bonus
            const referralCode = document.getElementById('referralCode').value.trim();
            if (referralCode) {
                handleReferralBonus(referralCode);
            }
            
            localStorage.setItem('earnflow_user', JSON.stringify({email, password}));
            loadUserProfile();
            showAppContainer();
            showMessage('Registration successful!', 'success');
        })
        .catch((error) => {
            showMessage('Registration failed: ' + error.message, 'error');
        })
        .finally(() => {
            showLoader(false);
        });
}

function generateReferralCode() {
    return Math.random().toString(36).substr(2, 8).toUpperCase();
}

function handleReferralBonus(referralCode) {
    database.ref('users').orderByChild('referralCode').equalTo(referralCode).once('value')
        .then((snapshot) => {
            if (snapshot.exists()) {
                const referrerData = Object.values(snapshot.val())[0];
                const referrerUid = referrerData.uid;
                
                // Give bonus to referrer
                const referrerRef = database.ref('users/' + referrerUid);
                referrerRef.child('balance').transaction((currentBalance) => {
                    return (currentBalance || 0) + 0.01; // $0.01 referral bonus
                });
                
                // Record referral
                database.ref('referrals').push({
                    referrer: referrerUid,
                    referred: currentUser.uid,
                    bonus: 0.01,
                    timestamp: Date.now()
                });
            }
        });
}

function loadUserProfile() {
    if (!currentUser) return;
    
    database.ref('users/' + currentUser.uid).on('value', (snapshot) => {
        if (snapshot.exists()) {
            userProfile = snapshot.val();
            updateUI();
        }
    });
}

function updateUI() {
    if (userProfile) {
        document.getElementById('userBalance').textContent = formatCurrency(userProfile.balance || 0);
    }
}

// Navigation functions
function toggleMenu() {
    document.getElementById('navMenu').classList.toggle('active');
    document.getElementById('navOverlay').classList.toggle('active');
}

function closeMenu() {
    document.getElementById('navMenu').classList.remove('active');
    document.getElementById('navOverlay').classList.remove('active');
}

function showDashboard() {
    clearContentArea();
    document.getElementById('dashboardView').classList.remove('hidden');
}

function clearContentArea() {
    document.getElementById('contentArea').innerHTML = '';
    document.getElementById('dashboardView').classList.add('hidden');
}

// Modal functions
function showModal(title, content) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = content;
    document.getElementById('modal').classList.add('active');
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

// Profile management
function showProfile() {
    const profileContent = `
        <div class="form-group">
            <label class="form-label">Profile Picture</label>
            <input type="file" id="profilePicture" class="form-control" accept="image/*">
        </div>
        <div class="form-group">
            <label class="form-label">Name</label>
            <input type="text" id="profileName" class="form-control" value="${userProfile?.name || ''}">
        </div>
        <div class="form-group">
            <label class="form-label">Email</label>
            <input type="email" id="profileEmail" class="form-control" value="${userProfile?.email || ''}" readonly>
        </div>
        <div class="form-group">
            <label class="form-label">New Password</label>
            <input type="password" id="newPassword" class="form-control" placeholder="Leave blank to keep current">
        </div>
        <button onclick="updateProfile()" class="btn btn-primary">Save Changes</button>
    `;
    showModal('Profile Settings', profileContent);
}

function updateProfile() {
    const name = document.getElementById('profileName').value.trim();
    const newPassword = document.getElementById('newPassword').value.trim();
    
    if (!name) {
        showMessage('Name is required', 'error');
        return;
    }
    
    showLoader(true);
    
    const updates = { name: name };
    
    database.ref('users/' + currentUser.uid).update(updates)
        .then(() => {
            if (newPassword) {
                return currentUser.updatePassword(newPassword);
            }
        })
        .then(() => {
            showMessage('Profile updated successfully!', 'success');
            closeModal();
        })
        .catch((error) => {
            showMessage('Update failed: ' + error.message, 'error');
        })
        .finally(() => {
            showLoader(false);
        });
}

// Withdraw system
function showWithdraw() {
    const withdrawContent = `
        <div class="form-group">
            <label class="form-label">Payment Method</label>
            <select id="withdrawMethod" class="form-select" onchange="updateWithdrawFields()">
                <option value="">Select Payment Method</option>
                <option value="jazzcash">JazzCash</option>
                <option value="easypaisa">EasyPaisa</option>
                <option value="sadapay">SadaPay</option>
                <option value="nayapay">NayaPay</option>
                <option value="bank">Bank Transfer</option>
                <option value="usdt">USDT TRC20</option>
            </select>
        </div>
        <div id="withdrawFields"></div>
        <div class="form-group">
            <label class="form-label">Amount (Minimum $10)</label>
            <input type="number" id="withdrawAmount" class="form-control" min="10" step="0.001">
        </div>
        <p>Available Balance: ${formatCurrency(userProfile?.balance || 0)}</p>
        <p>USDT Rate: $1 = Rs.250</p>
        <button onclick="submitWithdrawRequest()" class="btn btn-success">Submit Request</button>
    `;
    showModal('Withdraw Funds', withdrawContent);
}

function updateWithdrawFields() {
    const method = document.getElementById('withdrawMethod').value;
    const fieldsContainer = document.getElementById('withdrawFields');
    
    let fields = '';
    
    switch(method) {
        case 'jazzcash':
        case 'easypaisa':
        case 'sadapay':
        case 'nayapay':
            fields = `
                <div class="form-group">
                    <label class="form-label">Account Name</label>
                    <input type="text" id="accountName" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Account Number</label>
                    <input type="text" id="accountNumber" class="form-control">
                </div>
            `;
            break;
        case 'bank':
            fields = `
                <div class="form-group">
                    <label class="form-label">Account Name</label>
                    <input type="text" id="accountName" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Account Number</label>
                    <input type="text" id="accountNumber" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Bank Name</label>
                    <input type="text" id="bankName" class="form-control">
                </div>
            `;
            break;
        case 'usdt':
            fields = `
                <div class="form-group">
                    <label class="form-label">Wallet Name</label>
                    <input type="text" id="walletName" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">USDT TRC20 Address</label>
                    <input type="text" id="cryptoAddress" class="form-control">
                </div>
            `;
            break;
    }
    
    fieldsContainer.innerHTML = fields;
}

function submitWithdrawRequest() {
    const method = document.getElementById('withdrawMethod').value;
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    
    if (!method || !amount || amount < 10) {
        showMessage('Please fill all fields and ensure minimum amount is $10', 'error');
        return;
    }
    
    if (amount > userProfile.balance) {
        showMessage('Insufficient balance', 'error');
        return;
    }
    
    const accountData = {};
    
    switch(method) {
        case 'jazzcash':
        case 'easypaisa':
        case 'sadapay':
        case 'nayapay':
            accountData.accountName = document.getElementById('accountName').value;
            accountData.accountNumber = document.getElementById('accountNumber').value;
            break;
        case 'bank':
            accountData.accountName = document.getElementById('accountName').value;
            accountData.accountNumber = document.getElementById('accountNumber').value;
            accountData.bankName = document.getElementById('bankName').value;
            break;
        case 'usdt':
            accountData.walletName = document.getElementById('walletName').value;
            accountData.cryptoAddress = document.getElementById('cryptoAddress').value;
            break;
    }
    
    showLoader(true);
    
    const requestData = {
        userId: currentUser.uid,
        userName: userProfile.name,
        userEmail: userProfile.email,
        method: method,
        amount: amount,
        accountData: accountData,
        status: 'pending',
        timestamp: Date.now(),
        requestId: generateId()
    };
    
    // Deduct amount from balance immediately
    database.ref('users/' + currentUser.uid + '/balance').transaction((currentBalance) => {
        return Math.max(0, (currentBalance || 0) - amount);
    })
    .then(() => {
        return database.ref('withdrawRequests').push(requestData);
    })
    .then(() => {
        showMessage('Withdraw request submitted successfully!', 'success');
        closeModal();
    })
    .catch((error) => {
        showMessage('Failed to submit request: ' + error.message, 'error');
    })
    .finally(() => {
        showLoader(false);
    });
}

// Deposit system
function showDeposit() {
    loadDepositMethods();
}

function loadDepositMethods() {
    database.ref('paymentMethods/deposit').once('value')
        .then((snapshot) => {
            const methods = snapshot.val() || {};
            let methodsHtml = '';
            
            Object.entries(methods).forEach(([key, method]) => {
                if (method.enabled) {
                    methodsHtml += `
                        <div class="list-item" onclick="selectDepositMethod('${key}', ${JSON.stringify(method).replace(/"/g, '&quot;')})">
                            <span>${method.name}</span>
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    `;
                }
            });
            
            if (!methodsHtml) {
                methodsHtml = '<div class="empty-state">No deposit methods available</div>';
            }
            
            const depositContent = `
                <p>Select a payment method to deposit funds:</p>
                <div>${methodsHtml}</div>
            `;
            
            showModal('Deposit Funds', depositContent);
        });
}

function selectDepositMethod(methodKey, methodData) {
    const depositFormContent = `
        <div class="card">
            <h4>${methodData.name}</h4>
            <p><strong>Account Name:</strong> ${methodData.accountName}</p>
            <p><strong>Account Number:</strong> ${methodData.accountNumber}</p>
            ${methodData.bankName ? `<p><strong>Bank:</strong> ${methodData.bankName}</p>` : ''}
            <button onclick="copyToClipboard('${methodData.accountNumber}')" class="btn btn-sm btn-primary">Copy Account Number</button>
        </div>
        
        <div class="form-group">
            <label class="form-label">Amount (Minimum $1)</label>
            <input type="number" id="depositAmount" class="form-control" min="1" step="0.01">
        </div>
        
        <div class="form-group">
            <label class="form-label">Transaction ID</label>
            <input type="text" id="transactionId" class="form-control" placeholder="Enter transaction ID">
        </div>
        
        <div class="form-group">
            <label class="form-label">Screenshot (Optional)</label>
            <input type="file" id="depositScreenshot" class="form-control" accept="image/*">
        </div>
        
        <button onclick="submitDepositRequest('${methodKey}')" class="btn btn-success">Submit Request</button>
    `;
    
    showModal('Deposit via ' + methodData.name, depositFormContent);
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showMessage('Copied to clipboard!', 'success');
    });
}

function submitDepositRequest(methodKey) {
    const amount = parseFloat(document.getElementById('depositAmount').value);
    const transactionId = document.getElementById('transactionId').value.trim();
    
    if (!amount || amount < 1 || !transactionId) {
        showMessage('Please fill all required fields and ensure minimum amount is $1', 'error');
        return;
    }
    
    showLoader(true);
    
    const requestData = {
        userId: currentUser.uid,
        userName: userProfile.name,
        userEmail: userProfile.email,
        method: methodKey,
        amount: amount,
        transactionId: transactionId,
        status: 'pending',
        timestamp: Date.now(),
        requestId: generateId()
    };
    
    database.ref('depositRequests').push(requestData)
        .then(() => {
            showMessage('Deposit request submitted successfully!', 'success');
            closeModal();
        })
        .catch((error) => {
            showMessage('Failed to submit request: ' + error.message, 'error');
        })
        .finally(() => {
            showLoader(false);
        });
}

// Status page
function showStatus() {
    clearContentArea();
    
    const statusContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Withdrawal Requests</h3>
            </div>
            <div id="withdrawalStatus">Loading...</div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Deposit Requests</h3>
            </div>
            <div id="depositStatus">Loading...</div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Promotion Requests</h3>
            </div>
            <div id="promotionStatus">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = statusContent;
    loadUserRequests();
}

function loadUserRequests() {
    // Load withdrawal requests
    database.ref('withdrawRequests').orderByChild('userId').equalTo(currentUser.uid).once('value')
        .then((snapshot) => {
            const requests = snapshot.val() || {};
            let html = '';
            
            Object.entries(requests).forEach(([key, request]) => {
                const statusClass = `status-${request.status}`;
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${formatCurrency(request.amount)}</strong> via ${request.method}
                            <br><small>${formatDate(request.timestamp)}</small>
                        </div>
                        <span class="${statusClass}">${request.status.toUpperCase()}</span>
                    </div>
                `;
            });
            
            document.getElementById('withdrawalStatus').innerHTML = html || '<div class="empty-state">No withdrawal requests</div>';
        });
    
    // Load deposit requests
    database.ref('depositRequests').orderByChild('userId').equalTo(currentUser.uid).once('value')
        .then((snapshot) => {
            const requests = snapshot.val() || {};
            let html = '';
            
            Object.entries(requests).forEach(([key, request]) => {
                const statusClass = `status-${request.status}`;
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${formatCurrency(request.amount)}</strong> via ${request.method}
                            <br><small>${formatDate(request.timestamp)}</small>
                        </div>
                        <span class="${statusClass}">${request.status.toUpperCase()}</span>
                    </div>
                `;
            });
            
            document.getElementById('depositStatus').innerHTML = html || '<div class="empty-state">No deposit requests</div>';
        });
    
    // Load promotion requests
    database.ref('promotionRequests').orderByChild('userId').equalTo(currentUser.uid).once('value')
        .then((snapshot) => {
            const requests = snapshot.val() || {};
            let html = '';
            
            Object.entries(requests).forEach(([key, request]) => {
                const statusClass = `status-${request.status}`;
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${request.adType}</strong> - ${request.views} views
                            <br><small>${formatDate(request.timestamp)}</small>
                        </div>
                        <span class="${statusClass}">${request.status.toUpperCase()}</span>
                    </div>
                `;
            });
            
            document.getElementById('promotionStatus').innerHTML = html || '<div class="empty-state">No promotion requests</div>';
        });
}

// Watch Ads
function showWatchAds() {
    clearContentArea();
    
    // Check if user is blocked from watching ads
    const currentTime = Date.now();
    if (currentTime - lastAdTime < 20000) {
        const remainingTime = Math.ceil((20000 - (currentTime - lastAdTime)) / 1000);
        document.getElementById('contentArea').innerHTML = `
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Watch Ads</h3>
                </div>
                <div class="empty-state">
                    <i class="fas fa-clock"></i>
                    <p>Please wait ${remainingTime} seconds before watching another ad</p>
                </div>
            </div>
        `;
        return;
    }
    
    const adsContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Watch Ads</h3>
            </div>
            <div id="adsList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = adsContent;
    loadWatchAds();
}

function loadWatchAds() {
    database.ref('watchAds').once('value')
        .then((snapshot) => {
            const ads = snapshot.val() || {};
            let html = '';
            
            Object.entries(ads).forEach(([key, ad]) => {
                html += `
                    <div class="ad-item" onclick="watchAd('${key}', ${JSON.stringify(ad).replace(/"/g, '&quot;')})">
                        <div class="ad-title">${ad.title}</div>
                        <div class="ad-reward">Reward: ${formatCurrency(ad.reward)}</div>
                        <div>Timer: ${ad.timer}s</div>
                    </div>
                `;
            });
            
            document.getElementById('adsList').innerHTML = html || '<div class="empty-state">No ads available</div>';
        });
}

function watchAd(adKey, adData) {
    currentAd = { key: adKey, data: adData };
    adStartTime = Date.now();
    
    document.getElementById('adTitle').textContent = adData.title;
    document.getElementById('adFrame').src = adData.url;
    document.getElementById('adTimer').textContent = adData.timer;
    document.getElementById('adCloseBtn').classList.add('hidden');
    document.getElementById('getRewardBtn').classList.add('hidden');
    document.getElementById('adModal').classList.add('active');
    
    // Start countdown after 3 seconds delay
    setTimeout(() => {
        startAdTimer(adData.timer);
    }, 3000);
}

function startAdTimer(duration) {
    let timeLeft = duration;
    document.getElementById('adTimer').textContent = timeLeft;
    
    adTimer = setInterval(() => {
        timeLeft--;
        document.getElementById('adTimer').textContent = timeLeft;
        
        if (timeLeft <= 0) {
            clearInterval(adTimer);
            document.getElementById('adTimer').textContent = 'Complete!';
            document.getElementById('adCloseBtn').classList.remove('hidden');
            document.getElementById('getRewardBtn').classList.remove('hidden');
        }
    }, 1000);
}

function claimAdReward() {
    if (!currentAd) return;
    
    const reward = currentAd.data.reward;
    
    // Add reward to user balance
    database.ref('users/' + currentUser.uid + '/balance').transaction((currentBalance) => {
        return (currentBalance || 0) + reward;
    })
    .then(() => {
        // Update total earned
        return database.ref('users/' + currentUser.uid + '/totalEarned').transaction((currentEarned) => {
            return (currentEarned || 0) + reward;
        });
    })
    .then(() => {
        // Record ad view
        return database.ref('adViews').push({
            userId: currentUser.uid,
            adKey: currentAd.key,
            reward: reward,
            timestamp: Date.now()
        });
    })
    .then(() => {
        showMessage(`Reward of ${formatCurrency(reward)} added to your account!`, 'success');
        lastAdTime = Date.now();
        closeAdModal();
        showWatchAds(); // Refresh the ads list
    })
    .catch((error) => {
        showMessage('Failed to claim reward: ' + error.message, 'error');
    });
}

function closeAdModal() {
    if (adTimer) {
        clearInterval(adTimer);
        adTimer = null;
    }
    document.getElementById('adModal').classList.remove('active');
    document.getElementById('adFrame').src = '';
    currentAd = null;
}

// Shortlinks
function showShortlinks() {
    clearContentArea();
    
    const shortlinksContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Shortlink Tasks</h3>
            </div>
            <div id="shortlinksList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = shortlinksContent;
    loadShortlinks();
}

function loadShortlinks() {
    database.ref('shortlinks').once('value')
        .then((snapshot) => {
            const shortlinks = snapshot.val() || {};
            let html = '';
            
            Object.entries(shortlinks).forEach(([key, shortlink]) => {
                html += `
                    <div class="ad-item" onclick="openShortlink('${key}', ${JSON.stringify(shortlink).replace(/"/g, '&quot;')})">
                        <div class="ad-title">${shortlink.title}</div>
                        <div class="ad-reward">Reward: ${formatCurrency(shortlink.reward)}</div>
                    </div>
                `;
            });
            
            document.getElementById('shortlinksList').innerHTML = html || '<div class="empty-state">No shortlinks available</div>';
        });
}

function openShortlink(shortlinkKey, shortlinkData) {
    // Open shortlink in new window/tab
    const newWindow = window.open(shortlinkData.targetUrl, '_blank');
    
    // Show completion dialog
    setTimeout(() => {
        const confirmed = confirm('Have you completed the shortlink task? Click OK to claim your reward.');
        if (confirmed) {
            claimShortlinkReward(shortlinkKey, shortlinkData);
        }
    }, 5000);
}

function claimShortlinkReward(shortlinkKey, shortlinkData) {
    const reward = shortlinkData.reward;
    
    // Add reward to user balance
    database.ref('users/' + currentUser.uid + '/balance').transaction((currentBalance) => {
        return (currentBalance || 0) + reward;
    })
    .then(() => {
        return database.ref('users/' + currentUser.uid + '/totalEarned').transaction((currentEarned) => {
            return (currentEarned || 0) + reward;
        });
    })
    .then(() => {
        return database.ref('shortlinkViews').push({
            userId: currentUser.uid,
            shortlinkKey: shortlinkKey,
            reward: reward,
            timestamp: Date.now()
        });
    })
    .then(() => {
        showMessage(`Reward of ${formatCurrency(reward)} added to your account!`, 'success');
    })
    .catch((error) => {
        showMessage('Failed to claim reward: ' + error.message, 'error');
    });
}

// Faucet Ads
function showFaucetAds() {
    clearContentArea();
    
    const faucetContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Faucet Ads</h3>
            </div>
            <div id="faucetAdsList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = faucetContent;
    loadFaucetAds();
}

function loadFaucetAds() {
    database.ref('faucetAds').once('value')
        .then((snapshot) => {
            const ads = snapshot.val() || {};
            let html = '';
            
            Object.entries(ads).forEach(([key, ad]) => {
                html += `
                    <div class="ad-item" onclick="openFaucetAd('${key}', ${JSON.stringify(ad).replace(/"/g, '&quot;')})">
                        <div class="ad-title">${ad.title}</div>
                        <div class="ad-reward">Reward: ${formatCurrency(ad.reward)}</div>
                        <div class="btn btn-success">Get Now</div>
                    </div>
                `;
            });
            
            document.getElementById('faucetAdsList').innerHTML = html || '<div class="empty-state">No faucet ads available</div>';
        });
}

function openFaucetAd(adKey, adData) {
    // Open ad in fullscreen modal
    const adContent = `
        <iframe src="${adData.url}" style="width: 100%; height: 400px; border: none;"></iframe>
        <div class="timer" id="faucetTimer">10</div>
        <button id="faucetCloseBtn" class="btn btn-success hidden" onclick="claimFaucetReward('${adKey}', ${adData.reward})">Get Reward</button>
    `;
    
    showModal(adData.title, adContent);
    
    // Start 10 second timer
    let timeLeft = 10;
    const timer = setInterval(() => {
        timeLeft--;
        const timerElement = document.getElementById('faucetTimer');
        if (timerElement) {
            timerElement.textContent = timeLeft;
        }
        
        if (timeLeft <= 0) {
            clearInterval(timer);
            const closeBtn = document.getElementById('faucetCloseBtn');
            if (closeBtn) {
                closeBtn.classList.remove('hidden');
            }
            if (timerElement) {
                timerElement.textContent = 'Complete!';
            }
        }
    }, 1000);
}

function claimFaucetReward(adKey, reward) {
    database.ref('users/' + currentUser.uid + '/balance').transaction((currentBalance) => {
        return (currentBalance || 0) + reward;
    })
    .then(() => {
        return database.ref('users/' + currentUser.uid + '/totalEarned').transaction((currentEarned) => {
            return (currentEarned || 0) + reward;
        });
    })
    .then(() => {
        return database.ref('faucetViews').push({
            userId: currentUser.uid,
            adKey: adKey,
            reward: reward,
            timestamp: Date.now()
        });
    })
    .then(() => {
        showMessage(`Reward of ${formatCurrency(reward)} added to your account!`, 'success');
        closeModal();
    })
    .catch((error) => {
        showMessage('Failed to claim reward: ' + error.message, 'error');
    });
}

// Daily Check-in
function showDailyCheck() {
    clearContentArea();
    
    const dailyContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daily Check-in</h3>
            </div>
            <div id="dailyCheckContent">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = dailyContent;
    loadDailyCheck();
}

function loadDailyCheck() {
    const today = new Date().toDateString();
    const userChecks = userProfile?.dailyCheckStatus || {};
    
    database.ref('dailyRewards').once('value')
        .then((snapshot) => {
            const rewards = snapshot.val() || {};
            let html = '<div class="daily-check-grid">';
            
            for (let day = 1; day <= 7; day++) {
                const reward = rewards[`day${day}`] || 0.0005;
                const checked = userChecks[today] && userChecks[today].day === day;
                const canCheck = !userChecks[today] && day === 1; // Simplified: only allow day 1 check
                
                html += `
                    <div class="daily-check-item ${checked ? 'checked' : ''} ${canCheck ? 'available' : ''}">
                        <div class="day">Day ${day}</div>
                        <div class="reward">${formatCurrency(reward)}</div>
                        ${canCheck ? `<button onclick="claimDailyReward(${day}, ${reward})" class="btn btn-sm btn-success">Claim</button>` : ''}
                        ${checked ? '<i class="fas fa-check"></i>' : ''}
                    </div>
                `;
            }
            
            html += '</div>';
            
            if (userChecks[today]) {
                html += '<p class="text-center">You have already checked in today!</p>';
            }
            
            document.getElementById('dailyCheckContent').innerHTML = html;
        });
}

function claimDailyReward(day, reward) {
    const today = new Date().toDateString();
    
    database.ref('users/' + currentUser.uid + '/balance').transaction((currentBalance) => {
        return (currentBalance || 0) + reward;
    })
    .then(() => {
        return database.ref('users/' + currentUser.uid + '/totalEarned').transaction((currentEarned) => {
            return (currentEarned || 0) + reward;
        });
    })
    .then(() => {
        return database.ref('users/' + currentUser.uid + '/dailyCheckStatus/' + today).set({
            day: day,
            reward: reward,
            timestamp: Date.now()
        });
    })
    .then(() => {
        showMessage(`Daily reward of ${formatCurrency(reward)} claimed!`, 'success');
        loadDailyCheck();
    })
    .catch((error) => {
        showMessage('Failed to claim daily reward: ' + error.message, 'error');
    });
}

// Leaderboard
function showLeaderboard() {
    clearContentArea();
    
    const leaderboardContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Leaderboard</h3>
            </div>
            <div id="leaderboardList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = leaderboardContent;
    loadLeaderboard();
}

function loadLeaderboard() {
    database.ref('users').orderByChild('totalEarned').limitToLast(8).once('value')
        .then((snapshot) => {
            const users = [];
            snapshot.forEach((child) => {
                const user = child.val();
                if (user.totalEarned >= 10) { // Only show users with $10+ earned
                    users.push(user);
                }
            });
            
            users.reverse(); // Highest earners first
            
            let html = '';
            users.forEach((user, index) => {
                const rank = index + 1;
                const avatar = user.name.charAt(0).toUpperCase();
                const isTop3 = rank <= 3;
                
                html += `
                    <div class="leaderboard-item ${isTop3 ? 'top-three' : ''}">
                        <div class="leaderboard-rank">#${rank}</div>
                        <div class="leaderboard-avatar">${avatar}</div>
                        <div class="leaderboard-info">
                            <div class="leaderboard-name">${user.name}</div>
                            <div class="leaderboard-earnings">${formatCurrency(user.totalEarned)}</div>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('leaderboardList').innerHTML = html || '<div class="empty-state">No users in leaderboard yet</div>';
        });
}

// Promotion
function showPromotion() {
    const promotionContent = `
        <div class="form-group">
            <label class="form-label">Ad Type</label>
            <select id="promoAdType" class="form-select">
                <option value="watchAd">Watch Ads</option>
                <option value="shortlink">Shortlink</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">URL</label>
            <input type="url" id="promoUrl" class="form-control" placeholder="Enter your URL">
        </div>
        <div class="form-group">
            <label class="form-label">Timer (seconds)</label>
            <select id="promoTimer" class="form-select" onchange="updatePromoCost()">
                <option value="10">10 seconds</option>
                <option value="20">20 seconds</option>
                <option value="30">30 seconds</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Views (minimum 10)</label>
            <input type="number" id="promoViews" class="form-control" min="10" value="10" onchange="updatePromoCost()">
        </div>
        <div class="form-group">
            <label class="form-label">Title</label>
            <input type="text" id="promoTitle" class="form-control" placeholder="Enter ad title">
        </div>
        <div id="promoCostInfo">
            <p>Cost: <span id="promoCost">$0.10</span></p>
            <p>Your Balance: ${formatCurrency(userProfile?.balance || 0)}</p>
        </div>
        <button onclick="submitPromotionRequest()" class="btn btn-primary">Submit Promotion</button>
    `;
    
    showModal('Promote Your Content', promotionContent);
    updatePromoCost();
}

function updatePromoCost() {
    const timer = parseInt(document.getElementById('promoTimer')?.value || 10);
    const views = parseInt(document.getElementById('promoViews')?.value || 10);
    
    const pricePerView = timer === 10 ? 0.01 : timer === 20 ? 0.02 : 0.03;
    const totalCost = pricePerView * views;
    
    const costElement = document.getElementById('promoCost');
    if (costElement) {
        costElement.textContent = formatCurrency(totalCost);
    }
}

function submitPromotionRequest() {
    const adType = document.getElementById('promoAdType').value;
    const url = document.getElementById('promoUrl').value.trim();
    const timer = parseInt(document.getElementById('promoTimer').value);
    const views = parseInt(document.getElementById('promoViews').value);
    const title = document.getElementById('promoTitle').value.trim();
    
    if (!url || !title || views < 10) {
        showMessage('Please fill all fields and ensure minimum 10 views', 'error');
        return;
    }
    
    const pricePerView = timer === 10 ? 0.01 : timer === 20 ? 0.02 : 0.03;
    const totalCost = pricePerView * views;
    
    if (totalCost > userProfile.balance) {
        showMessage('Insufficient balance. Please deposit funds first.', 'error');
        return;
    }
    
    showLoader(true);
    
    const requestData = {
        userId: currentUser.uid,
        userName: userProfile.name,
        adType: adType,
        url: url,
        timer: timer,
        views: views,
        title: title,
        cost: totalCost,
        status: 'pending',
        timestamp: Date.now(),
        requestId: generateId()
    };
    
    // Deduct cost from balance
    database.ref('users/' + currentUser.uid + '/balance').transaction((currentBalance) => {
        return Math.max(0, (currentBalance || 0) - totalCost);
    })
    .then(() => {
        return database.ref('promotionRequests').push(requestData);
    })
    .then(() => {
        showMessage('Promotion request submitted successfully!', 'success');
        closeModal();
    })
    .catch((error) => {
        showMessage('Failed to submit request: ' + error.message, 'error');
    })
    .finally(() => {
        showLoader(false);
    });
}

// Referral system
function showReferrals() {
    const referralContent = `
        <div class="text-center">
            <h4>Invite Friends & Earn</h4>
            <p>Share EarnFlow with your friends and earn $0.01 for each successful referral!</p>
            
            <div class="form-group">
                <label class="form-label">Your Referral Code</label>
                <div class="flex align-center gap-10">
                    <input type="text" id="userReferralCode" class="form-control" value="${userProfile?.referralCode || ''}" readonly>
                    <button onclick="copyToClipboard('${userProfile?.referralCode || ''}')" class="btn btn-primary">Copy</button>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Share Link</label>
                <div class="flex align-center gap-10">
                    <input type="text" id="shareLink" class="form-control" value="${window.location.origin}/user.html?ref=${userProfile?.referralCode || ''}" readonly>
                    <button onclick="copyToClipboard('${window.location.origin}/user.html?ref=${userProfile?.referralCode || ''}')" class="btn btn-primary">Copy</button>
                </div>
            </div>
            
            <button onclick="shareViaWhatsApp()" class="btn btn-success">Share via WhatsApp</button>
        </div>
        
        <div class="mt-20">
            <h5>Your Referrals</h5>
            <div id="referralsList">Loading...</div>
        </div>
    `;
    
    showModal('Referral Program', referralContent);
    loadUserReferrals();
}

function shareViaWhatsApp() {
    const shareText = `Join EarnFlow and start earning money online! Use my referral code: ${userProfile?.referralCode} ${window.location.origin}/user.html?ref=${userProfile?.referralCode}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    window.open(whatsappUrl, '_blank');
}

function loadUserReferrals() {
    database.ref('referrals').orderByChild('referrer').equalTo(currentUser.uid).once('value')
        .then((snapshot) => {
            const referrals = snapshot.val() || {};
            let html = '';
            let totalEarned = 0;
            
            Object.entries(referrals).forEach(([key, referral]) => {
                totalEarned += referral.bonus;
                html += `
                    <div class="list-item">
                        <div>Referral Bonus</div>
                        <div class="status-approved">+${formatCurrency(referral.bonus)}</div>
                    </div>
                `;
            });
            
            if (html) {
                html = `<div class="mb-20"><strong>Total Earned: ${formatCurrency(totalEarned)}</strong></div>` + html;
            } else {
                html = '<div class="empty-state">No referrals yet</div>';
            }
            
            document.getElementById('referralsList').innerHTML = html;
        });
}

// Redeem Code
function showRedeemCode() {
    const redeemContent = `
        <div class="form-group">
            <label class="form-label">Enter Redeem Code</label>
            <input type="text" id="redeemCodeInput" class="form-control" placeholder="Enter your code">
        </div>
        <button onclick="redeemCode()" class="btn btn-success">Redeem Code</button>
        
        <div class="mt-20 text-center">
            <p>Don't have a code?</p>
            <button onclick="getRedeemCode()" class="btn btn-primary">Get Code</button>
        </div>
    `;
    
    showModal('Redeem Code', redeemContent);
}

function redeemCode() {
    const code = document.getElementById('redeemCodeInput').value.trim().toUpperCase();
    
    if (!code) {
        showMessage('Please enter a code', 'error');
        return;
    }
    
    showLoader(true);
    
    // Check if code exists and is valid
    database.ref('redeemCodes/' + code).once('value')
        .then((snapshot) => {
            if (!snapshot.exists()) {
                throw new Error('Invalid code');
            }
            
            const codeData = snapshot.val();
            
            // Check if user has already used this code
            return database.ref('redeemHistory').orderByChild('userId').equalTo(currentUser.uid).once('value')
                .then((historySnapshot) => {
                    const history = historySnapshot.val() || {};
                    const alreadyUsed = Object.values(history).some(record => record.code === code);
                    
                    if (alreadyUsed) {
                        throw new Error('Code already used');
                    }
                    
                    return codeData;
                });
        })
        .then((codeData) => {
            // Add reward to user balance
            return database.ref('users/' + currentUser.uid + '/balance').transaction((currentBalance) => {
                return (currentBalance || 0) + codeData.reward;
            })
            .then(() => {
                return database.ref('users/' + currentUser.uid + '/totalEarned').transaction((currentEarned) => {
                    return (currentEarned || 0) + codeData.reward;
                });
            })
            .then(() => {
                // Record redemption
                return database.ref('redeemHistory').push({
                    userId: currentUser.uid,
                    code: code,
                    reward: codeData.reward,
                    timestamp: Date.now()
                });
            })
            .then(() => {
                showMessage(`Code redeemed! ${formatCurrency(codeData.reward)} added to your account!`, 'success');
                closeModal();
            });
        })
        .catch((error) => {
            showMessage(error.message || 'Failed to redeem code', 'error');
        })
        .finally(() => {
            showLoader(false);
        });
}

function getRedeemCode() {
    database.ref('appSettings/redeemCodeUrl').once('value')
        .then((snapshot) => {
            const url = snapshot.val() || '#';
            window.open(url, '_blank');
        });
}

// Contact/Chat
function showContact() {
    clearContentArea();
    
    const chatContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Contact Support</h3>
            </div>
            <div class="chat-container">
                <div class="chat-messages" id="chatMessages">
                    <!-- Messages will be loaded here -->
                </div>
                <div class="chat-input-container">
                    <input type="text" id="chatInput" class="chat-input form-control" placeholder="Type your message...">
                    <button onclick="sendMessage()" class="btn btn-primary">Send</button>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = chatContent;
    loadChatMessages();
}

function loadChatMessages() {
    database.ref('chats/' + currentUser.uid).on('value', (snapshot) => {
        const messages = snapshot.val() || {};
        let html = '';
        
        Object.entries(messages).forEach(([key, message]) => {
            const messageClass = message.sender === 'user' ? 'user' : 'admin';
            html += `
                <div class="chat-message ${messageClass}">
                    <div>${message.text}</div>
                    <small>${formatDate(message.timestamp)}</small>
                </div>
            `;
        });
        
        const chatContainer = document.getElementById('chatMessages');
        if (chatContainer) {
            chatContainer.innerHTML = html;
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    });
}

function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    const messageData = {
        sender: 'user',
        text: message,
        timestamp: Date.now(),
        userName: userProfile.name
    };
    
    database.ref('chats/' + currentUser.uid).push(messageData)
        .then(() => {
            input.value = '';
        })
        .catch((error) => {
            showMessage('Failed to send message: ' + error.message, 'error');
        });
}

// Add event listener for Enter key in chat
document.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        const chatInput = document.getElementById('chatInput');
        if (chatInput && document.activeElement === chatInput) {
            sendMessage();
        }
    }
});

// Logout
function logout() {
    auth.signOut().then(() => {
        localStorage.removeItem('earnflow_user');
        currentUser = null;
        userProfile = null;
        showAuthContainer();
        showMessage('Logged out successfully', 'success');
    });
}

// Check for referral code in URL
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const refCode = urlParams.get('ref');
    if (refCode) {
        document.getElementById('referralCode').value = refCode;
    }
});
