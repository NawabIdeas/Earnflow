// Admin Authentication and Session Management
let adminUser = null;
let adminProfile = null;
let usersData = {};
let statsData = {};

// Initialize admin session
document.addEventListener('DOMContentLoaded', function() {
    checkAdminSession();
});

function checkAdminSession() {
    const savedAdmin = localStorage.getItem('earnflow_admin');
    if (savedAdmin) {
        const adminData = JSON.parse(savedAdmin);
        auth.signInWithEmailAndPassword(adminData.email, adminData.password)
            .then(() => {
                adminUser = auth.currentUser;
                // Check if user is admin
                return database.ref('admins/' + adminUser.uid).once('value');
            })
            .then((snapshot) => {
                if (snapshot.exists()) {
                    adminProfile = snapshot.val();
                    showAdminContainer();
                    loadAdminDashboard();
                } else {
                    throw new Error('Not authorized as admin');
                }
            })
            .catch(() => {
                localStorage.removeItem('earnflow_admin');
                showAuthContainer();
            });
    } else {
        showAuthContainer();
    }
}

function showAuthContainer() {
    document.getElementById('authContainer').classList.remove('hidden');
    document.getElementById('adminContainer').classList.add('hidden');
}

function showAdminContainer() {
    document.getElementById('authContainer').classList.add('hidden');
    document.getElementById('adminContainer').classList.remove('hidden');
}

function adminLogin() {
    const email = document.getElementById('adminEmail').value.trim();
    const password = document.getElementById('adminPassword').value.trim();
    
    if (!email || !password) {
        showMessage('Please fill in all fields', 'error');
        return;
    }
    
    showLoader(true);
    
    auth.signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            adminUser = userCredential.user;
            
            // Check if user is admin
            return database.ref('admins/' + adminUser.uid).once('value');
        })
        .then((snapshot) => {
            if (!snapshot.exists()) {
                throw new Error('Not authorized as admin');
            }
            
            adminProfile = snapshot.val();
            localStorage.setItem('earnflow_admin', JSON.stringify({email, password}));
            showAdminContainer();
            loadAdminDashboard();
            showMessage('Admin login successful!', 'success');
        })
        .catch((error) => {
            showMessage('Login failed: ' + error.message, 'error');
        })
        .finally(() => {
            showLoader(false);
        });
}

// Navigation functions
function toggleMenu() {
    document.getElementById('navMenu').classList.toggle('active');
    document.getElementById('navOverlay').classList.toggle('active');
}

function closeMenu() {
    document.getElementById('navMenu').classList.remove('active');
    document.getElementById('navOverlay').classList.remove('active');
}

function showAdminDashboard() {
    clearContentArea();
    document.getElementById('adminDashboardView').classList.remove('hidden');
    loadAdminDashboard();
}

function clearContentArea() {
    document.getElementById('contentArea').innerHTML = '';
    document.getElementById('adminDashboardView').classList.add('hidden');
}

// Modal functions
function showModal(title, content) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = content;
    document.getElementById('modal').classList.add('active');
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

// Dashboard functions
function loadAdminDashboard() {
    loadStats();
    loadUsersList();
}

function loadStats() {
    // Load total users
    database.ref('users').once('value')
        .then((snapshot) => {
            const users = snapshot.val() || {};
            const totalUsers = Object.keys(users).length;
            document.getElementById('totalUsers').textContent = totalUsers;
            
            // Calculate total revenue and daily revenue
            let totalRevenue = 0;
            let dailyRevenue = 0;
            const today = new Date().toDateString();
            
            Object.values(users).forEach(user => {
                if (user.totalEarned) {
                    totalRevenue += user.totalEarned;
                }
            });
            
            // Load daily revenue from settings
            return database.ref('appSettings/dailyRevenue').once('value');
        })
        .then((snapshot) => {
            const dailyRevenue = snapshot.val() || 0;
            document.getElementById('totalRevenue').textContent = formatCurrency(0); // Revenue calculation would depend on business model
            document.getElementById('dailyRevenue').textContent = formatCurrency(dailyRevenue);
        });
    
    // Load pending requests count
    Promise.all([
        database.ref('withdrawRequests').orderByChild('status').equalTo('pending').once('value'),
        database.ref('depositRequests').orderByChild('status').equalTo('pending').once('value'),
        database.ref('promotionRequests').orderByChild('status').equalTo('pending').once('value')
    ]).then(([withdrawSnapshot, depositSnapshot, promotionSnapshot]) => {
        const withdrawCount = Object.keys(withdrawSnapshot.val() || {}).length;
        const depositCount = Object.keys(depositSnapshot.val() || {}).length;
        const promotionCount = Object.keys(promotionSnapshot.val() || {}).length;
        const totalPending = withdrawCount + depositCount + promotionCount;
        
        document.getElementById('pendingRequests').textContent = totalPending;
    });
}

function loadUsersList() {
    database.ref('users').limitToLast(10).once('value')
        .then((snapshot) => {
            const users = snapshot.val() || {};
            let html = '';
            
            Object.entries(users).forEach(([uid, user]) => {
                html += `
                    <div class="list-item" onclick="showUserDetails('${uid}')">
                        <div>
                            <strong>${user.name}</strong>
                            <br><small>${user.email}</small>
                            <br><span class="status-approved">${formatCurrency(user.balance || 0)}</span>
                        </div>
                        <div>
                            <button class="btn btn-sm btn-primary" onclick="editUser('${uid}'); event.stopPropagation();">Edit</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('usersList').innerHTML = html || '<div class="empty-state">No users found</div>';
        });
}

function showUserDetails(userId) {
    database.ref('users/' + userId).once('value')
        .then((snapshot) => {
            const user = snapshot.val();
            if (!user) return;
            
            const userDetailsContent = `
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" value="${user.name}" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" value="${user.email}" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Balance</label>
                    <input type="text" class="form-control" value="${formatCurrency(user.balance || 0)}" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Total Earned</label>
                    <input type="text" class="form-control" value="${formatCurrency(user.totalEarned || 0)}" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <input type="text" class="form-control" value="${user.status || 'active'}" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Join Date</label>
                    <input type="text" class="form-control" value="${formatDate(user.joinDate)}" readonly>
                </div>
                <div class="action-buttons">
                    <button onclick="editUser('${userId}')" class="btn btn-primary">Edit User</button>
                    <button onclick="blockUser('${userId}')" class="btn btn-warning">Block User</button>
                    <button onclick="deleteUser('${userId}')" class="btn btn-danger">Delete User</button>
                </div>
            `;
            
            showModal('User Details', userDetailsContent);
        });
}

function editUser(userId) {
    database.ref('users/' + userId).once('value')
        .then((snapshot) => {
            const user = snapshot.val();
            if (!user) return;
            
            const editUserContent = `
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" id="editUserName" class="form-control" value="${user.name}">
                </div>
                <div class="form-group">
                    <label class="form-label">Balance</label>
                    <input type="number" id="editUserBalance" class="form-control" value="${user.balance || 0}" step="0.001">
                </div>
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select id="editUserStatus" class="form-select">
                        <option value="active" ${user.status === 'active' ? 'selected' : ''}>Active</option>
                        <option value="blocked" ${user.status === 'blocked' ? 'selected' : ''}>Blocked</option>
                        <option value="suspended" ${user.status === 'suspended' ? 'selected' : ''}>Suspended</option>
                    </select>
                </div>
                <button onclick="updateUser('${userId}')" class="btn btn-success">Update User</button>
            `;
            
            showModal('Edit User', editUserContent);
        });
}

function updateUser(userId) {
    const name = document.getElementById('editUserName').value.trim();
    const balance = parseFloat(document.getElementById('editUserBalance').value);
    const status = document.getElementById('editUserStatus').value;
    
    if (!name || isNaN(balance)) {
        showMessage('Please fill all fields correctly', 'error');
        return;
    }
    
    showLoader(true);
    
    const updates = {
        name: name,
        balance: balance,
        status: status
    };
    
    database.ref('users/' + userId).update(updates)
        .then(() => {
            showMessage('User updated successfully!', 'success');
            closeModal();
            loadUsersList();
        })
        .catch((error) => {
            showMessage('Failed to update user: ' + error.message, 'error');
        })
        .finally(() => {
            showLoader(false);
        });
}

function blockUser(userId) {
    if (confirm('Are you sure you want to block this user?')) {
        database.ref('users/' + userId + '/status').set('blocked')
            .then(() => {
                showMessage('User blocked successfully!', 'success');
                closeModal();
                loadUsersList();
            })
            .catch((error) => {
                showMessage('Failed to block user: ' + error.message, 'error');
            });
    }
}

function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        database.ref('users/' + userId).remove()
            .then(() => {
                showMessage('User deleted successfully!', 'success');
                closeModal();
                loadUsersList();
            })
            .catch((error) => {
                showMessage('Failed to delete user: ' + error.message, 'error');
            });
    }
}

function resetDailyRevenue() {
    if (confirm('Are you sure you want to reset daily revenue?')) {
        database.ref('appSettings/dailyRevenue').set(0)
            .then(() => {
                showMessage('Daily revenue reset successfully!', 'success');
                loadStats();
            })
            .catch((error) => {
                showMessage('Failed to reset daily revenue: ' + error.message, 'error');
            });
    }
}

// Requests Management
function showRequests() {
    clearContentArea();
    
    const requestsContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Withdrawal Requests</h3>
            </div>
            <div id="withdrawRequestsList">Loading...</div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Deposit Requests</h3>
            </div>
            <div id="depositRequestsList">Loading...</div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Promotion Requests</h3>
            </div>
            <div id="promotionRequestsList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = requestsContent;
    loadAllRequests();
}

function loadAllRequests() {
    loadWithdrawRequests();
    loadDepositRequests();
    loadPromotionRequests();
}

function loadWithdrawRequests() {
    database.ref('withdrawRequests').orderByChild('status').equalTo('pending').once('value')
        .then((snapshot) => {
            const requests = snapshot.val() || {};
            let html = '';
            
            Object.entries(requests).forEach(([key, request]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${request.userName}</strong> - ${formatCurrency(request.amount)}
                            <br><small>${request.method} | ${formatDate(request.timestamp)}</small>
                            <br><small>Email: ${request.userEmail}</small>
                        </div>
                        <div>
                            <button onclick="viewWithdrawDetails('${key}')" class="btn btn-sm btn-primary">View</button>
                            <button onclick="approveWithdrawRequest('${key}')" class="btn btn-sm btn-success">Approve</button>
                            <button onclick="rejectWithdrawRequest('${key}')" class="btn btn-sm btn-danger">Reject</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('withdrawRequestsList').innerHTML = html || '<div class="empty-state">No pending withdrawal requests</div>';
        });
}

function viewWithdrawDetails(requestKey) {
    database.ref('withdrawRequests/' + requestKey).once('value')
        .then((snapshot) => {
            const request = snapshot.val();
            if (!request) return;
            
            let accountInfo = '';
            const accountData = request.accountData;
            
            switch(request.method) {
                case 'jazzcash':
                case 'easypaisa':
                case 'sadapay':
                case 'nayapay':
                    accountInfo = `
                        <p><strong>Account Name:</strong> ${accountData.accountName}</p>
                        <p><strong>Account Number:</strong> ${accountData.accountNumber}</p>
                    `;
                    break;
                case 'bank':
                    accountInfo = `
                        <p><strong>Account Name:</strong> ${accountData.accountName}</p>
                        <p><strong>Account Number:</strong> ${accountData.accountNumber}</p>
                        <p><strong>Bank Name:</strong> ${accountData.bankName}</p>
                    `;
                    break;
                case 'usdt':
                    accountInfo = `
                        <p><strong>Wallet Name:</strong> ${accountData.walletName}</p>
                        <p><strong>USDT Address:</strong> ${accountData.cryptoAddress}</p>
                    `;
                    break;
            }
            
            const detailsContent = `
                <div class="form-group">
                    <label class="form-label">User</label>
                    <p>${request.userName} (${request.userEmail})</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Amount</label>
                    <p>${formatCurrency(request.amount)}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Method</label>
                    <p>${request.method}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Account Details</label>
                    ${accountInfo}
                </div>
                <div class="form-group">
                    <label class="form-label">Request Date</label>
                    <p>${formatDate(request.timestamp)}</p>
                </div>
                <div class="action-buttons">
                    <button onclick="approveWithdrawRequest('${requestKey}')" class="btn btn-success">Approve</button>
                    <button onclick="rejectWithdrawRequest('${requestKey}')" class="btn btn-danger">Reject</button>
                </div>
            `;
            
            showModal('Withdrawal Request Details', detailsContent);
        });
}

function approveWithdrawRequest(requestKey) {
    if (confirm('Are you sure you want to approve this withdrawal request?')) {
        database.ref('withdrawRequests/' + requestKey + '/status').set('approved')
            .then(() => {
                showMessage('Withdrawal request approved!', 'success');
                closeModal();
                loadWithdrawRequests();
            })
            .catch((error) => {
                showMessage('Failed to approve request: ' + error.message, 'error');
            });
    }
}

function rejectWithdrawRequest(requestKey) {
    if (confirm('Are you sure you want to reject this withdrawal request? The amount will be refunded to user.')) {
        database.ref('withdrawRequests/' + requestKey).once('value')
            .then((snapshot) => {
                const request = snapshot.val();
                
                // Refund amount to user
                return database.ref('users/' + request.userId + '/balance').transaction((currentBalance) => {
                    return (currentBalance || 0) + request.amount;
                });
            })
            .then(() => {
                return database.ref('withdrawRequests/' + requestKey + '/status').set('rejected');
            })
            .then(() => {
                showMessage('Withdrawal request rejected and amount refunded!', 'success');
                closeModal();
                loadWithdrawRequests();
            })
            .catch((error) => {
                showMessage('Failed to reject request: ' + error.message, 'error');
            });
    }
}

function loadDepositRequests() {
    database.ref('depositRequests').orderByChild('status').equalTo('pending').once('value')
        .then((snapshot) => {
            const requests = snapshot.val() || {};
            let html = '';
            
            Object.entries(requests).forEach(([key, request]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${request.userName}</strong> - ${formatCurrency(request.amount)}
                            <br><small>${request.method} | ${formatDate(request.timestamp)}</small>
                            <br><small>TID: ${request.transactionId}</small>
                        </div>
                        <div>
                            <button onclick="viewDepositDetails('${key}')" class="btn btn-sm btn-primary">View</button>
                            <button onclick="approveDepositRequest('${key}')" class="btn btn-sm btn-success">Approve</button>
                            <button onclick="rejectDepositRequest('${key}')" class="btn btn-sm btn-danger">Reject</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('depositRequestsList').innerHTML = html || '<div class="empty-state">No pending deposit requests</div>';
        });
}

function viewDepositDetails(requestKey) {
    database.ref('depositRequests/' + requestKey).once('value')
        .then((snapshot) => {
            const request = snapshot.val();
            if (!request) return;
            
            const detailsContent = `
                <div class="form-group">
                    <label class="form-label">User</label>
                    <p>${request.userName} (${request.userEmail})</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Amount</label>
                    <p>${formatCurrency(request.amount)}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Method</label>
                    <p>${request.method}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Transaction ID</label>
                    <p>${request.transactionId}</p>
                    <button onclick="copyToClipboard('${request.transactionId}')" class="btn btn-sm btn-primary">Copy</button>
                </div>
                <div class="form-group">
                    <label class="form-label">Request Date</label>
                    <p>${formatDate(request.timestamp)}</p>
                </div>
                <div class="action-buttons">
                    <button onclick="approveDepositRequest('${requestKey}')" class="btn btn-success">Approve</button>
                    <button onclick="rejectDepositRequest('${requestKey}')" class="btn btn-danger">Reject</button>
                </div>
            `;
            
            showModal('Deposit Request Details', detailsContent);
        });
}

function approveDepositRequest(requestKey) {
    if (confirm('Are you sure you want to approve this deposit request?')) {
        database.ref('depositRequests/' + requestKey).once('value')
            .then((snapshot) => {
                const request = snapshot.val();
                
                // Add amount to user balance
                return database.ref('users/' + request.userId + '/balance').transaction((currentBalance) => {
                    return (currentBalance || 0) + request.amount;
                });
            })
            .then(() => {
                return database.ref('depositRequests/' + requestKey + '/status').set('approved');
            })
            .then(() => {
                showMessage('Deposit request approved and amount added to user account!', 'success');
                closeModal();
                loadDepositRequests();
            })
            .catch((error) => {
                showMessage('Failed to approve request: ' + error.message, 'error');
            });
    }
}

function rejectDepositRequest(requestKey) {
    if (confirm('Are you sure you want to reject this deposit request?')) {
        database.ref('depositRequests/' + requestKey + '/status').set('rejected')
            .then(() => {
                showMessage('Deposit request rejected!', 'success');
                closeModal();
                loadDepositRequests();
            })
            .catch((error) => {
                showMessage('Failed to reject request: ' + error.message, 'error');
            });
    }
}

function loadPromotionRequests() {
    database.ref('promotionRequests').orderByChild('status').equalTo('pending').once('value')
        .then((snapshot) => {
            const requests = snapshot.val() || {};
            let html = '';
            
            Object.entries(requests).forEach(([key, request]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${request.userName}</strong> - ${request.adType}
                            <br><small>${request.views} views | ${formatCurrency(request.cost)}</small>
                            <br><small>${formatDate(request.timestamp)}</small>
                        </div>
                        <div>
                            <button onclick="viewPromotionDetails('${key}')" class="btn btn-sm btn-primary">View</button>
                            <button onclick="approvePromotionRequest('${key}')" class="btn btn-sm btn-success">Approve</button>
                            <button onclick="rejectPromotionRequest('${key}')" class="btn btn-sm btn-danger">Reject</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('promotionRequestsList').innerHTML = html || '<div class="empty-state">No pending promotion requests</div>';
        });
}

function viewPromotionDetails(requestKey) {
    database.ref('promotionRequests/' + requestKey).once('value')
        .then((snapshot) => {
            const request = snapshot.val();
            if (!request) return;
            
            const detailsContent = `
                <div class="form-group">
                    <label class="form-label">User</label>
                    <p>${request.userName}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Ad Type</label>
                    <p>${request.adType}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Title</label>
                    <p>${request.title}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">URL</label>
                    <p><a href="${request.url}" target="_blank">${request.url}</a></p>
                </div>
                <div class="form-group">
                    <label class="form-label">Timer</label>
                    <p>${request.timer} seconds</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Views</label>
                    <p>${request.views}</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Cost</label>
                    <p>${formatCurrency(request.cost)}</p>
                </div>
                <div class="action-buttons">
                    <button onclick="approvePromotionRequest('${requestKey}')" class="btn btn-success">Approve</button>
                    <button onclick="rejectPromotionRequest('${requestKey}')" class="btn btn-danger">Reject</button>
                </div>
            `;
            
            showModal('Promotion Request Details', detailsContent);
        });
}

function approvePromotionRequest(requestKey) {
    if (confirm('Are you sure you want to approve this promotion request?')) {
        database.ref('promotionRequests/' + requestKey).once('value')
            .then((snapshot) => {
                const request = snapshot.val();
                
                // Add to appropriate ads collection
                const adData = {
                    title: request.title,
                    url: request.url,
                    timer: request.timer,
                    reward: 0.001, // Default reward for promoted ads
                    promotedBy: request.userId,
                    targetViews: request.views,
                    currentViews: 0,
                    timestamp: Date.now()
                };
                
                const collection = request.adType === 'watchAd' ? 'watchAds' : 'shortlinks';
                return database.ref(collection).push(adData);
            })
            .then(() => {
                return database.ref('promotionRequests/' + requestKey + '/status').set('approved');
            })
            .then(() => {
                showMessage('Promotion request approved and ad published!', 'success');
                closeModal();
                loadPromotionRequests();
            })
            .catch((error) => {
                showMessage('Failed to approve request: ' + error.message, 'error');
            });
    }
}

function rejectPromotionRequest(requestKey) {
    if (confirm('Are you sure you want to reject this promotion request? The amount will be refunded.')) {
        database.ref('promotionRequests/' + requestKey).once('value')
            .then((snapshot) => {
                const request = snapshot.val();
                
                // Refund amount to user
                return database.ref('users/' + request.userId + '/balance').transaction((currentBalance) => {
                    return (currentBalance || 0) + request.cost;
                });
            })
            .then(() => {
                return database.ref('promotionRequests/' + requestKey + '/status').set('rejected');
            })
            .then(() => {
                showMessage('Promotion request rejected and amount refunded!', 'success');
                closeModal();
                loadPromotionRequests();
            })
            .catch((error) => {
                showMessage('Failed to reject request: ' + error.message, 'error');
            });
    }
}

// Watch Ads Manager
function showWatchAdsManager() {
    clearContentArea();
    
    const adsManagerContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Watch Ads Manager</h3>
                <button onclick="showAddWatchAd()" class="btn btn-primary">Add New Ad</button>
            </div>
            <div id="watchAdsList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = adsManagerContent;
    loadWatchAdsList();
}

function loadWatchAdsList() {
    database.ref('watchAds').once('value')
        .then((snapshot) => {
            const ads = snapshot.val() || {};
            let html = '';
            
            Object.entries(ads).forEach(([key, ad]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${ad.title}</strong>
                            <br><small>Reward: ${formatCurrency(ad.reward)} | Timer: ${ad.timer}s</small>
                            <br><small>URL: ${ad.url}</small>
                        </div>
                        <div>
                            <button onclick="editWatchAd('${key}')" class="btn btn-sm btn-primary">Edit</button>
                            <button onclick="deleteWatchAd('${key}')" class="btn btn-sm btn-danger">Delete</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('watchAdsList').innerHTML = html || '<div class="empty-state">No watch ads available</div>';
        });
}

function showAddWatchAd() {
    const addAdContent = `
        <div class="form-group">
            <label class="form-label">Title</label>
            <input type="text" id="adTitle" class="form-control" placeholder="Enter ad title">
        </div>
        <div class="form-group">
            <label class="form-label">URL</label>
            <input type="url" id="adUrl" class="form-control" placeholder="Enter ad URL">
        </div>
        <div class="form-group">
            <label class="form-label">Timer (seconds)</label>
            <input type="number" id="adTimer" class="form-control" min="5" max="120" value="30">
        </div>
        <div class="form-group">
            <label class="form-label">Reward ($)</label>
            <input type="number" id="adReward" class="form-control" step="0.0001" value="0.0001">
        </div>
        <button onclick="addWatchAd()" class="btn btn-success">Add Ad</button>
    `;
    
    showModal('Add Watch Ad', addAdContent);
}

function addWatchAd() {
    const title = document.getElementById('adTitle').value.trim();
    const url = document.getElementById('adUrl').value.trim();
    const timer = parseInt(document.getElementById('adTimer').value);
    const reward = parseFloat(document.getElementById('adReward').value);
    
    if (!title || !url || !timer || !reward) {
        showMessage('Please fill all fields', 'error');
        return;
    }
    
    const adData = {
        title: title,
        url: url,
        timer: timer,
        reward: reward,
        timestamp: Date.now()
    };
    
    database.ref('watchAds').push(adData)
        .then(() => {
            showMessage('Watch ad added successfully!', 'success');
            closeModal();
            loadWatchAdsList();
        })
        .catch((error) => {
            showMessage('Failed to add ad: ' + error.message, 'error');
        });
}

function editWatchAd(adKey) {
    database.ref('watchAds/' + adKey).once('value')
        .then((snapshot) => {
            const ad = snapshot.val();
            if (!ad) return;
            
            const editAdContent = `
                <div class="form-group">
                    <label class="form-label">Title</label>
                    <input type="text" id="editAdTitle" class="form-control" value="${ad.title}">
                </div>
                <div class="form-group">
                    <label class="form-label">URL</label>
                    <input type="url" id="editAdUrl" class="form-control" value="${ad.url}">
                </div>
                <div class="form-group">
                    <label class="form-label">Timer (seconds)</label>
                    <input type="number" id="editAdTimer" class="form-control" value="${ad.timer}">
                </div>
                <div class="form-group">
                    <label class="form-label">Reward ($)</label>
                    <input type="number" id="editAdReward" class="form-control" step="0.0001" value="${ad.reward}">
                </div>
                <button onclick="updateWatchAd('${adKey}')" class="btn btn-success">Update Ad</button>
            `;
            
            showModal('Edit Watch Ad', editAdContent);
        });
}

function updateWatchAd(adKey) {
    const title = document.getElementById('editAdTitle').value.trim();
    const url = document.getElementById('editAdUrl').value.trim();
    const timer = parseInt(document.getElementById('editAdTimer').value);
    const reward = parseFloat(document.getElementById('editAdReward').value);
    
    if (!title || !url || !timer || !reward) {
        showMessage('Please fill all fields', 'error');
        return;
    }
    
    const updates = {
        title: title,
        url: url,
        timer: timer,
        reward: reward
    };
    
    database.ref('watchAds/' + adKey).update(updates)
        .then(() => {
            showMessage('Watch ad updated successfully!', 'success');
            closeModal();
            loadWatchAdsList();
        })
        .catch((error) => {
            showMessage('Failed to update ad: ' + error.message, 'error');
        });
}

function deleteWatchAd(adKey) {
    if (confirm('Are you sure you want to delete this ad?')) {
        database.ref('watchAds/' + adKey).remove()
            .then(() => {
                showMessage('Watch ad deleted successfully!', 'success');
                loadWatchAdsList();
            })
            .catch((error) => {
                showMessage('Failed to delete ad: ' + error.message, 'error');
            });
    }
}

// Shortlink Manager
function showShortlinkManager() {
    clearContentArea();
    
    const shortlinkManagerContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Shortlink Manager</h3>
                <button onclick="showAddShortlink()" class="btn btn-primary">Add New Shortlink</button>
            </div>
            <div id="shortlinksList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = shortlinkManagerContent;
    loadShortlinksList();
}

function loadShortlinksList() {
    database.ref('shortlinks').once('value')
        .then((snapshot) => {
            const shortlinks = snapshot.val() || {};
            let html = '';
            
            Object.entries(shortlinks).forEach(([key, shortlink]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${shortlink.title}</strong>
                            <br><small>Reward: ${formatCurrency(shortlink.reward)}</small>
                            <br><small>URL: ${shortlink.targetUrl}</small>
                        </div>
                        <div>
                            <button onclick="editShortlink('${key}')" class="btn btn-sm btn-primary">Edit</button>
                            <button onclick="deleteShortlink('${key}')" class="btn btn-sm btn-danger">Delete</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('shortlinksList').innerHTML = html || '<div class="empty-state">No shortlinks available</div>';
        });
}

function showAddShortlink() {
    const addShortlinkContent = `
        <div class="form-group">
            <label class="form-label">Title</label>
            <input type="text" id="shortlinkTitle" class="form-control" placeholder="Enter shortlink title">
        </div>
        <div class="form-group">
            <label class="form-label">Target URL</label>
            <input type="url" id="shortlinkUrl" class="form-control" placeholder="Enter target URL">
        </div>
        <div class="form-group">
            <label class="form-label">Reward ($)</label>
            <input type="number" id="shortlinkReward" class="form-control" step="0.0001" value="0.0009">
        </div>
        <button onclick="addShortlink()" class="btn btn-success">Add Shortlink</button>
    `;
    
    showModal('Add Shortlink', addShortlinkContent);
}

function addShortlink() {
    const title = document.getElementById('shortlinkTitle').value.trim();
    const targetUrl = document.getElementById('shortlinkUrl').value.trim();
    const reward = parseFloat(document.getElementById('shortlinkReward').value);
    
    if (!title || !targetUrl || !reward) {
        showMessage('Please fill all fields', 'error');
        return;
    }
    
    const shortlinkData = {
        title: title,
        targetUrl: targetUrl,
        reward: reward,
        timestamp: Date.now()
    };
    
    database.ref('shortlinks').push(shortlinkData)
        .then(() => {
            showMessage('Shortlink added successfully!', 'success');
            closeModal();
            loadShortlinksList();
        })
        .catch((error) => {
            showMessage('Failed to add shortlink: ' + error.message, 'error');
        });
}

function editShortlink(shortlinkKey) {
    database.ref('shortlinks/' + shortlinkKey).once('value')
        .then((snapshot) => {
            const shortlink = snapshot.val();
            if (!shortlink) return;
            
            const editShortlinkContent = `
                <div class="form-group">
                    <label class="form-label">Title</label>
                    <input type="text" id="editShortlinkTitle" class="form-control" value="${shortlink.title}">
                </div>
                <div class="form-group">
                    <label class="form-label">Target URL</label>
                    <input type="url" id="editShortlinkUrl" class="form-control" value="${shortlink.targetUrl}">
                </div>
                <div class="form-group">
                    <label class="form-label">Reward ($)</label>
                    <input type="number" id="editShortlinkReward" class="form-control" step="0.0001" value="${shortlink.reward}">
                </div>
                <button onclick="updateShortlink('${shortlinkKey}')" class="btn btn-success">Update Shortlink</button>
            `;
            
            showModal('Edit Shortlink', editShortlinkContent);
        });
}

function updateShortlink(shortlinkKey) {
    const title = document.getElementById('editShortlinkTitle').value.trim();
    const targetUrl = document.getElementById('editShortlinkUrl').value.trim();
    const reward = parseFloat(document.getElementById('editShortlinkReward').value);
    
    if (!title || !targetUrl || !reward) {
        showMessage('Please fill all fields', 'error');
        return;
    }
    
    const updates = {
        title: title,
        targetUrl: targetUrl,
        reward: reward
    };
    
    database.ref('shortlinks/' + shortlinkKey).update(updates)
        .then(() => {
            showMessage('Shortlink updated successfully!', 'success');
            closeModal();
            loadShortlinksList();
        })
        .catch((error) => {
            showMessage('Failed to update shortlink: ' + error.message, 'error');
        });
}

function deleteShortlink(shortlinkKey) {
    if (confirm('Are you sure you want to delete this shortlink?')) {
        database.ref('shortlinks/' + shortlinkKey).remove()
            .then(() => {
                showMessage('Shortlink deleted successfully!', 'success');
                loadShortlinksList();
            })
            .catch((error) => {
                showMessage('Failed to delete shortlink: ' + error.message, 'error');
            });
    }
}

// Faucet Ads Manager
function showFaucetAdsManager() {
    clearContentArea();
    
    const faucetManagerContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Faucet Ads Manager</h3>
                <button onclick="showAddFaucetAd()" class="btn btn-primary">Add New Faucet Ad</button>
            </div>
            <div id="faucetAdsList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = faucetManagerContent;
    loadFaucetAdsList();
}

function loadFaucetAdsList() {
    database.ref('faucetAds').once('value')
        .then((snapshot) => {
            const ads = snapshot.val() || {};
            let html = '';
            
            Object.entries(ads).forEach(([key, ad]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${ad.title}</strong>
                            <br><small>Reward: ${formatCurrency(ad.reward)}</small>
                            <br><small>URL: ${ad.url}</small>
                        </div>
                        <div>
                            <button onclick="editFaucetAd('${key}')" class="btn btn-sm btn-primary">Edit</button>
                            <button onclick="deleteFaucetAd('${key}')" class="btn btn-sm btn-danger">Delete</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('faucetAdsList').innerHTML = html || '<div class="empty-state">No faucet ads available</div>';
        });
}

function showAddFaucetAd() {
    const addFaucetAdContent = `
        <div class="form-group">
            <label class="form-label">Title</label>
            <input type="text" id="faucetAdTitle" class="form-control" placeholder="Enter ad title">
        </div>
        <div class="form-group">
            <label class="form-label">URL</label>
            <input type="url" id="faucetAdUrl" class="form-control" placeholder="Enter ad URL">
        </div>
        <div class="form-group">
            <label class="form-label">Reward ($)</label>
            <input type="number" id="faucetAdReward" class="form-control" step="0.0001" value="0.001">
        </div>
        <button onclick="addFaucetAd()" class="btn btn-success">Add Faucet Ad</button>
    `;
    
    showModal('Add Faucet Ad', addFaucetAdContent);
}

function addFaucetAd() {
    const title = document.getElementById('faucetAdTitle').value.trim();
    const url = document.getElementById('faucetAdUrl').value.trim();
    const reward = parseFloat(document.getElementById('faucetAdReward').value);
    
    if (!title || !url || !reward) {
        showMessage('Please fill all fields', 'error');
        return;
    }
    
    const adData = {
        title: title,
        url: url,
        reward: reward,
        timestamp: Date.now()
    };
    
    database.ref('faucetAds').push(adData)
        .then(() => {
            showMessage('Faucet ad added successfully!', 'success');
            closeModal();
            loadFaucetAdsList();
        })
        .catch((error) => {
            showMessage('Failed to add faucet ad: ' + error.message, 'error');
        });
}

function editFaucetAd(adKey) {
    database.ref('faucetAds/' + adKey).once('value')
        .then((snapshot) => {
            const ad = snapshot.val();
            if (!ad) return;
            
            const editFaucetAdContent = `
                <div class="form-group">
                    <label class="form-label">Title</label>
                    <input type="text" id="editFaucetAdTitle" class="form-control" value="${ad.title}">
                </div>
                <div class="form-group">
                    <label class="form-label">URL</label>
                    <input type="url" id="editFaucetAdUrl" class="form-control" value="${ad.url}">
                </div>
                <div class="form-group">
                    <label class="form-label">Reward ($)</label>
                    <input type="number" id="editFaucetAdReward" class="form-control" step="0.0001" value="${ad.reward}">
                </div>
                <button onclick="updateFaucetAd('${adKey}')" class="btn btn-success">Update Faucet Ad</button>
            `;
            
            showModal('Edit Faucet Ad', editFaucetAdContent);
        });
}

function updateFaucetAd(adKey) {
    const title = document.getElementById('editFaucetAdTitle').value.trim();
    const url = document.getElementById('editFaucetAdUrl').value.trim();
    const reward = parseFloat(document.getElementById('editFaucetAdReward').value);
    
    if (!title || !url || !reward) {
        showMessage('Please fill all fields', 'error');
        return;
    }
    
    const updates = {
        title: title,
        url: url,
        reward: reward
    };
    
    database.ref('faucetAds/' + adKey).update(updates)
        .then(() => {
            showMessage('Faucet ad updated successfully!', 'success');
            closeModal();
            loadFaucetAdsList();
        })
        .catch((error) => {
            showMessage('Failed to update faucet ad: ' + error.message, 'error');
        });
}

function deleteFaucetAd(adKey) {
    if (confirm('Are you sure you want to delete this faucet ad?')) {
        database.ref('faucetAds/' + adKey).remove()
            .then(() => {
                showMessage('Faucet ad deleted successfully!', 'success');
                loadFaucetAdsList();
            })
            .catch((error) => {
                showMessage('Failed to delete faucet ad: ' + error.message, 'error');
            });
    }
}

// Daily Check Manager
function showDailyCheckManager() {
    clearContentArea();
    
    const dailyCheckContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daily Check-in Rewards</h3>
            </div>
            <div id="dailyRewardsList">Loading...</div>
            <button onclick="updateDailyRewards()" class="btn btn-primary">Update Rewards</button>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = dailyCheckContent;
    loadDailyRewards();
}

function loadDailyRewards() {
    database.ref('dailyRewards').once('value')
        .then((snapshot) => {
            const rewards = snapshot.val() || {};
            let html = '<div class="daily-rewards-grid">';
            
            for (let day = 1; day <= 7; day++) {
                const reward = rewards[`day${day}`] || 0.0005;
                html += `
                    <div class="form-group">
                        <label class="form-label">Day ${day} Reward ($)</label>
                        <input type="number" id="day${day}Reward" class="form-control" step="0.0001" value="${reward}">
                    </div>
                `;
            }
            
            html += '</div>';
            document.getElementById('dailyRewardsList').innerHTML = html;
        });
}

function updateDailyRewards() {
    const updates = {};
    
    for (let day = 1; day <= 7; day++) {
        const reward = parseFloat(document.getElementById(`day${day}Reward`).value);
        if (!isNaN(reward)) {
            updates[`day${day}`] = reward;
        }
    }
    
    database.ref('dailyRewards').update(updates)
        .then(() => {
            showMessage('Daily rewards updated successfully!', 'success');
        })
        .catch((error) => {
            showMessage('Failed to update daily rewards: ' + error.message, 'error');
        });
}

// Redeem Code Manager
function showRedeemCodeManager() {
    clearContentArea();
    
    const redeemCodeContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Redeem Code Manager</h3>
                <button onclick="showAddRedeemCode()" class="btn btn-primary">Add New Code</button>
            </div>
            <div id="redeemCodesList">Loading...</div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">External URL Settings</h3>
            </div>
            <div class="form-group">
                <label class="form-label">Redeem Code URL</label>
                <input type="url" id="redeemCodeUrl" class="form-control" placeholder="Enter external URL for getting codes">
            </div>
            <button onclick="updateRedeemCodeUrl()" class="btn btn-success">Update URL</button>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = redeemCodeContent;
    loadRedeemCodes();
    loadRedeemCodeUrl();
}

function loadRedeemCodes() {
    database.ref('redeemCodes').once('value')
        .then((snapshot) => {
            const codes = snapshot.val() || {};
            let html = '';
            
            Object.entries(codes).forEach(([code, data]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${code}</strong>
                            <br><small>Reward: ${formatCurrency(data.reward)}</small>
                        </div>
                        <div>
                            <button onclick="deleteRedeemCode('${code}')" class="btn btn-sm btn-danger">Delete</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('redeemCodesList').innerHTML = html || '<div class="empty-state">No redeem codes available</div>';
        });
}

function showAddRedeemCode() {
    const addCodeContent = `
        <div class="form-group">
            <label class="form-label">Code</label>
            <input type="text" id="newRedeemCode" class="form-control" placeholder="Enter redeem code">
        </div>
        <div class="form-group">
            <label class="form-label">Reward ($)</label>
            <input type="number" id="newCodeReward" class="form-control" step="0.0001" value="0.005">
        </div>
        <button onclick="addRedeemCode()" class="btn btn-success">Add Code</button>
    `;
    
    showModal('Add Redeem Code', addCodeContent);
}

function addRedeemCode() {
    const code = document.getElementById('newRedeemCode').value.trim().toUpperCase();
    const reward = parseFloat(document.getElementById('newCodeReward').value);
    
    if (!code || !reward) {
        showMessage('Please fill all fields', 'error');
        return;
    }
    
    const codeData = {
        reward: reward,
        timestamp: Date.now()
    };
    
    database.ref('redeemCodes/' + code).set(codeData)
        .then(() => {
            showMessage('Redeem code added successfully!', 'success');
            closeModal();
            loadRedeemCodes();
        })
        .catch((error) => {
            showMessage('Failed to add redeem code: ' + error.message, 'error');
        });
}

function deleteRedeemCode(code) {
    if (confirm('Are you sure you want to delete this redeem code?')) {
        database.ref('redeemCodes/' + code).remove()
            .then(() => {
                showMessage('Redeem code deleted successfully!', 'success');
                loadRedeemCodes();
            })
            .catch((error) => {
                showMessage('Failed to delete redeem code: ' + error.message, 'error');
            });
    }
}

function loadRedeemCodeUrl() {
    database.ref('appSettings/redeemCodeUrl').once('value')
        .then((snapshot) => {
            const url = snapshot.val() || '';
            document.getElementById('redeemCodeUrl').value = url;
        });
}

function updateRedeemCodeUrl() {
    const url = document.getElementById('redeemCodeUrl').value.trim();
    
    database.ref('appSettings/redeemCodeUrl').set(url)
        .then(() => {
            showMessage('Redeem code URL updated successfully!', 'success');
        })
        .catch((error) => {
            showMessage('Failed to update URL: ' + error.message, 'error');
        });
}

// Contact Manager
function showContactManager() {
    clearContentArea();
    
    const contactContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">User Messages</h3>
            </div>
            <div id="userChatsList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = contactContent;
    loadUserChats();
}

function loadUserChats() {
    database.ref('chats').once('value')
        .then((snapshot) => {
            const chats = snapshot.val() || {};
            let html = '';
            
            Object.entries(chats).forEach(([userId, messages]) => {
                const lastMessage = Object.values(messages).pop();
                
                // Get user name
                database.ref('users/' + userId + '/name').once('value')
                    .then((userSnapshot) => {
                        const userName = userSnapshot.val() || 'Unknown User';
                        
                        html += `
                            <div class="list-item" onclick="openUserChat('${userId}', '${userName}')">
                                <div>
                                    <strong>${userName}</strong>
                                    <br><small>${lastMessage ? lastMessage.text.substring(0, 50) + '...' : 'No messages'}</small>
                                </div>
                                <div>
                                    <i class="fas fa-chevron-right"></i>
                                </div>
                            </div>
                        `;
                        
                        document.getElementById('userChatsList').innerHTML = html || '<div class="empty-state">No messages</div>';
                    });
            });
            
            if (Object.keys(chats).length === 0) {
                document.getElementById('userChatsList').innerHTML = '<div class="empty-state">No messages</div>';
            }
        });
}

function openUserChat(userId, userName) {
    const chatContent = `
        <div class="chat-container">
            <div class="chat-messages" id="adminChatMessages" style="height: 300px;">
                <!-- Messages will be loaded here -->
            </div>
            <div class="chat-input-container">
                <input type="text" id="adminChatInput" class="chat-input form-control" placeholder="Type your reply...">
                <button onclick="sendAdminMessage('${userId}')" class="btn btn-primary">Send</button>
                <button onclick="deleteUserChat('${userId}')" class="btn btn-danger">Delete Chat</button>
            </div>
        </div>
    `;
    
    showModal('Chat with ' + userName, chatContent);
    loadAdminChatMessages(userId);
}

function loadAdminChatMessages(userId) {
    database.ref('chats/' + userId).on('value', (snapshot) => {
        const messages = snapshot.val() || {};
        let html = '';
        
        Object.entries(messages).forEach(([key, message]) => {
            const messageClass = message.sender === 'user' ? 'user' : 'admin';
            html += `
                <div class="chat-message ${messageClass}">
                    <div>${message.text}</div>
                    <small>${formatDate(message.timestamp)}</small>
                </div>
            `;
        });
        
        const chatContainer = document.getElementById('adminChatMessages');
        if (chatContainer) {
            chatContainer.innerHTML = html;
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    });
}

function sendAdminMessage(userId) {
    const input = document.getElementById('adminChatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    const messageData = {
        sender: 'admin',
        text: message,
        timestamp: Date.now()
    };
    
    database.ref('chats/' + userId).push(messageData)
        .then(() => {
            input.value = '';
        })
        .catch((error) => {
            showMessage('Failed to send message: ' + error.message, 'error');
        });
}

function deleteUserChat(userId) {
    if (confirm('Are you sure you want to delete this entire chat conversation?')) {
        database.ref('chats/' + userId).remove()
            .then(() => {
                showMessage('Chat deleted successfully!', 'success');
                closeModal();
                loadUserChats();
            })
            .catch((error) => {
                showMessage('Failed to delete chat: ' + error.message, 'error');
            });
    }
}

// Settings
function showSettings() {
    clearContentArea();
    
    const settingsContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Promotion Pricing</h3>
            </div>
            <div class="form-group">
                <label class="form-label">10 seconds ($)</label>
                <input type="number" id="price10s" class="form-control" step="0.01" value="0.01">
            </div>
            <div class="form-group">
                <label class="form-label">20 seconds ($)</label>
                <input type="number" id="price20s" class="form-control" step="0.01" value="0.02">
            </div>
            <div class="form-group">
                <label class="form-label">30 seconds ($)</label>
                <input type="number" id="price30s" class="form-control" step="0.01" value="0.03">
            </div>
            <button onclick="updatePromotionPricing()" class="btn btn-success">Update Pricing</button>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">App Settings</h3>
            </div>
            <div class="form-group">
                <label class="form-label">App Name</label>
                <input type="text" id="appName" class="form-control" value="EarnFlow">
            </div>
            <div class="form-group">
                <label class="form-label">Minimum Withdrawal ($)</label>
                <input type="number" id="minWithdrawal" class="form-control" step="0.01" value="10">
            </div>
            <div class="form-group">
                <label class="form-label">Minimum Deposit ($)</label>
                <input type="number" id="minDeposit" class="form-control" step="0.01" value="1">
            </div>
            <div class="form-group">
                <label class="form-label">USDT Rate (PKR per $1)</label>
                <input type="number" id="usdtRate" class="form-control" value="250">
            </div>
            <button onclick="updateAppSettings()" class="btn btn-success">Update Settings</button>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = settingsContent;
    loadSettings();
}

function loadSettings() {
    database.ref('appSettings').once('value')
        .then((snapshot) => {
            const settings = snapshot.val() || {};
            
            if (settings.promotionPricing) {
                document.getElementById('price10s').value = settings.promotionPricing.s10 || 0.01;
                document.getElementById('price20s').value = settings.promotionPricing.s20 || 0.02;
                document.getElementById('price30s').value = settings.promotionPricing.s30 || 0.03;
            }
            
            document.getElementById('appName').value = settings.appName || 'EarnFlow';
            document.getElementById('minWithdrawal').value = settings.minWithdrawal || 10;
            document.getElementById('minDeposit').value = settings.minDeposit || 1;
            document.getElementById('usdtRate').value = settings.usdtRate || 250;
        });
}

function updatePromotionPricing() {
    const pricing = {
        s10: parseFloat(document.getElementById('price10s').value),
        s20: parseFloat(document.getElementById('price20s').value),
        s30: parseFloat(document.getElementById('price30s').value)
    };
    
    database.ref('appSettings/promotionPricing').set(pricing)
        .then(() => {
            showMessage('Promotion pricing updated successfully!', 'success');
        })
        .catch((error) => {
            showMessage('Failed to update pricing: ' + error.message, 'error');
        });
}

function updateAppSettings() {
    const settings = {
        appName: document.getElementById('appName').value.trim(),
        minWithdrawal: parseFloat(document.getElementById('minWithdrawal').value),
        minDeposit: parseFloat(document.getElementById('minDeposit').value),
        usdtRate: parseFloat(document.getElementById('usdtRate').value)
    };
    
    database.ref('appSettings').update(settings)
        .then(() => {
            showMessage('App settings updated successfully!', 'success');
        })
        .catch((error) => {
            showMessage('Failed to update settings: ' + error.message, 'error');
        });
}

// Payment Methods
function showPaymentMethods() {
    clearContentArea();
    
    const paymentMethodsContent = `
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Withdrawal Methods</h3>
                <button onclick="showAddWithdrawMethod()" class="btn btn-primary">Add Method</button>
            </div>
            <div id="withdrawMethodsList">Loading...</div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Deposit Methods</h3>
                <button onclick="showAddDepositMethod()" class="btn btn-primary">Add Method</button>
            </div>
            <div id="depositMethodsList">Loading...</div>
        </div>
    `;
    
    document.getElementById('contentArea').innerHTML = paymentMethodsContent;
    loadPaymentMethods();
}

function loadPaymentMethods() {
    // Load withdrawal methods
    database.ref('paymentMethods/withdraw').once('value')
        .then((snapshot) => {
            const methods = snapshot.val() || {};
            let html = '';
            
            Object.entries(methods).forEach(([key, method]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${method.name}</strong>
                            <br><small>Status: ${method.enabled ? 'Enabled' : 'Disabled'}</small>
                        </div>
                        <div>
                            <button onclick="editWithdrawMethod('${key}')" class="btn btn-sm btn-primary">Edit</button>
                            <button onclick="toggleMethodStatus('withdraw', '${key}', ${!method.enabled})" class="btn btn-sm ${method.enabled ? 'btn-warning' : 'btn-success'}">
                                ${method.enabled ? 'Disable' : 'Enable'}
                            </button>
                            <button onclick="deletePaymentMethod('withdraw', '${key}')" class="btn btn-sm btn-danger">Delete</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('withdrawMethodsList').innerHTML = html || '<div class="empty-state">No withdrawal methods</div>';
        });
    
    // Load deposit methods
    database.ref('paymentMethods/deposit').once('value')
        .then((snapshot) => {
            const methods = snapshot.val() || {};
            let html = '';
            
            Object.entries(methods).forEach(([key, method]) => {
                html += `
                    <div class="list-item">
                        <div>
                            <strong>${method.name}</strong>
                            <br><small>Account: ${method.accountNumber}</small>
                            <br><small>Status: ${method.enabled ? 'Enabled' : 'Disabled'}</small>
                        </div>
                        <div>
                            <button onclick="editDepositMethod('${key}')" class="btn btn-sm btn-primary">Edit</button>
                            <button onclick="toggleMethodStatus('deposit', '${key}', ${!method.enabled})" class="btn btn-sm ${method.enabled ? 'btn-warning' : 'btn-success'}">
                                ${method.enabled ? 'Disable' : 'Enable'}
                            </button>
                            <button onclick="deletePaymentMethod('deposit', '${key}')" class="btn btn-sm btn-danger">Delete</button>
                        </div>
                    </div>
                `;
            });
            
            document.getElementById('depositMethodsList').innerHTML = html || '<div class="empty-state">No deposit methods</div>';
        });
}

function showAddDepositMethod() {
    const addMethodContent = `
        <div class="form-group">
            <label class="form-label">Method Name</label>
            <input type="text" id="depositMethodName" class="form-control" placeholder="e.g., JazzCash">
        </div>
        <div class="form-group">
            <label class="form-label">Account Name</label>
            <input type="text" id="depositAccountName" class="form-control" placeholder="Account holder name">
        </div>
        <div class="form-group">
            <label class="form-label">Account Number</label>
            <input type="text" id="depositAccountNumber" class="form-control" placeholder="Account number">
        </div>
        <div class="form-group">
            <label class="form-label">Bank Name (Optional)</label>
            <input type="text" id="depositBankName" class="form-control" placeholder="Bank name if applicable">
        </div>
        <div class="form-group">
            <label class="form-label">URL (Optional)</label>
            <input type="url" id="depositUrl" class="form-control" placeholder="Optional URL">
        </div>
        <button onclick="addDepositMethod()" class="btn btn-success">Add Method</button>
    `;
    
    showModal('Add Deposit Method', addMethodContent);
}

function addDepositMethod() {
    const name = document.getElementById('depositMethodName').value.trim();
    const accountName = document.getElementById('depositAccountName').value.trim();
    const accountNumber = document.getElementById('depositAccountNumber').value.trim();
    const bankName = document.getElementById('depositBankName').value.trim();
    const url = document.getElementById('depositUrl').value.trim();
    
    if (!name || !accountName || !accountNumber) {
        showMessage('Please fill required fields', 'error');
        return;
    }
    
    const methodData = {
        name: name,
        accountName: accountName,
        accountNumber: accountNumber,
        bankName: bankName || null,
        url: url || null,
        enabled: true,
        timestamp: Date.now()
    };
    
    database.ref('paymentMethods/deposit').push(methodData)
        .then(() => {
            showMessage('Deposit method added successfully!', 'success');
            closeModal();
            loadPaymentMethods();
        })
        .catch((error) => {
            showMessage('Failed to add method: ' + error.message, 'error');
        });
}

function editDepositMethod(methodKey) {
    database.ref('paymentMethods/deposit/' + methodKey).once('value')
        .then((snapshot) => {
            const method = snapshot.val();
            if (!method) return;
            
            const editMethodContent = `
                <div class="form-group">
                    <label class="form-label">Method Name</label>
                    <input type="text" id="editDepositMethodName" class="form-control" value="${method.name}">
                </div>
                <div class="form-group">
                    <label class="form-label">Account Name</label>
                    <input type="text" id="editDepositAccountName" class="form-control" value="${method.accountName}">
                </div>
                <div class="form-group">
                    <label class="form-label">Account Number</label>
                    <input type="text" id="editDepositAccountNumber" class="form-control" value="${method.accountNumber}">
                </div>
                <div class="form-group">
                    <label class="form-label">Bank Name (Optional)</label>
                    <input type="text" id="editDepositBankName" class="form-control" value="${method.bankName || ''}">
                </div>
                <div class="form-group">
                    <label class="form-label">URL (Optional)</label>
                    <input type="url" id="editDepositUrl" class="form-control" value="${method.url || ''}">
                </div>
                <button onclick="updateDepositMethod('${methodKey}')" class="btn btn-success">Update Method</button>
            `;
            
            showModal('Edit Deposit Method', editMethodContent);
        });
}

function updateDepositMethod(methodKey) {
    const name = document.getElementById('editDepositMethodName').value.trim();
    const accountName = document.getElementById('editDepositAccountName').value.trim();
    const accountNumber = document.getElementById('editDepositAccountNumber').value.trim();
    const bankName = document.getElementById('editDepositBankName').value.trim();
    const url = document.getElementById('editDepositUrl').value.trim();
    
    if (!name || !accountName || !accountNumber) {
        showMessage('Please fill required fields', 'error');
        return;
    }
    
    const updates = {
        name: name,
        accountName: accountName,
        accountNumber: accountNumber,
        bankName: bankName || null,
        url: url || null
    };
    
    database.ref('paymentMethods/deposit/' + methodKey).update(updates)
        .then(() => {
            showMessage('Deposit method updated successfully!', 'success');
            closeModal();
            loadPaymentMethods();
        })
        .catch((error) => {
            showMessage('Failed to update method: ' + error.message, 'error');
        });
}

function toggleMethodStatus(type, methodKey, enabled) {
    database.ref(`paymentMethods/${type}/${methodKey}/enabled`).set(enabled)
        .then(() => {
            showMessage(`Method ${enabled ? 'enabled' : 'disabled'} successfully!`, 'success');
            loadPaymentMethods();
        })
        .catch((error) => {
            showMessage('Failed to update method status: ' + error.message, 'error');
        });
}

function deletePaymentMethod(type, methodKey) {
    if (confirm('Are you sure you want to delete this payment method?')) {
        database.ref(`paymentMethods/${type}/${methodKey}`).remove()
            .then(() => {
                showMessage('Payment method deleted successfully!', 'success');
                loadPaymentMethods();
            })
            .catch((error) => {
                showMessage('Failed to delete method: ' + error.message, 'error');
            });
    }
}

// Utility functions
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showMessage('Copied to clipboard!', 'success');
    });
}

// Logout
function logout() {
    auth.signOut().then(() => {
        localStorage.removeItem('earnflow_admin');
        adminUser = null;
        adminProfile = null;
        showAuthContainer();
        showMessage('Logged out successfully', 'success');
    });
}

// Add event listener for Enter key in admin chat
document.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        const adminChatInput = document.getElementById('adminChatInput');
        if (adminChatInput && document.activeElement === adminChatInput) {
            const userId = adminChatInput.getAttribute('data-user-id');
            if (userId) {
                sendAdminMessage(userId);
            }
        }
    }
});
