// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCBYyzCR5iDihKG-YgiKGnPTqWSRgEscrw",
  authDomain: "earnflow-3cqoj.firebaseapp.com",
  databaseURL: "https://earnflow-3cqoj-default-rtdb.firebaseio.com",
  projectId: "earnflow-3cqoj",
  storageBucket: "earnflow-3cqoj.firebasestorage.app",
  messagingSenderId: "557959267984",
  appId: "1:557959267984:web:2230ffd284b72812723a15"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize services
const auth = firebase.auth();
const database = firebase.database();
const storage = firebase.storage();

// Global variables
let currentUser = null;
let userProfile = null;

// Common utility functions
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function formatCurrency(amount) {
  return '$' + parseFloat(amount).toFixed(3);
}

function formatDate(timestamp) {
  return new Date(timestamp).toLocaleDateString() + ' ' + new Date(timestamp).toLocaleTimeString();
}

function showMessage(message, type = 'info') {
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${type}`;
  messageDiv.textContent = message;
  messageDiv.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    z-index: 10000;
    max-width: 300px;
    word-wrap: break-word;
  `;
  
  switch(type) {
    case 'success':
      messageDiv.style.backgroundColor = '#4CAF50';
      break;
    case 'error':
      messageDiv.style.backgroundColor = '#f44336';
      break;
    case 'warning':
      messageDiv.style.backgroundColor = '#ff9800';
      break;
    default:
      messageDiv.style.backgroundColor = '#2196F3';
  }
  
  document.body.appendChild(messageDiv);
  
  setTimeout(() => {
    messageDiv.remove();
  }, 5000);
}

function showLoader(show = true) {
  let loader = document.getElementById('loader');
  if (!loader) {
    loader = document.createElement('div');
    loader.id = 'loader';
    loader.innerHTML = '<div class="spinner"></div>';
    loader.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.8);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    `;
    document.body.appendChild(loader);
  }
  loader.style.display = show ? 'flex' : 'none';
}
